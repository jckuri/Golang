go test cmd/client_tests/client_test.go -v -run TestDeleteAllQuestions
