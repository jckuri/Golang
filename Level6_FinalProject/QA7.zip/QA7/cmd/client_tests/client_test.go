package main

import (
    "testing"
    "reflect"
    "qa/pkg"
)

func TestDeleteAllQuestions(t *testing.T) {
    err := qa.DeleteAllQuestions()
    if err != nil {
        t.Error(err)    
    }
    qas, err := qa.ReadAllQuestions()
    if err != nil {
        t.Error(err)    
    }
    if len(qas) != 0 {
        t.Errorf("Some questions were not deleted.")
    }
}

func CreateQuestionTest(t *testing.T, qa0 qa.QA) {
    qa1, err1 := qa.CreateQuestion(qa0)
    if err1 != nil {
        t.Error(err1)
    }
    qa1_test, err1_test := qa.ReadQuestion(qa1.Id)
    if err1_test != nil {
        t.Error(err1_test)
    }
    if qa1 != qa1_test {
        t.Errorf("Got: %+v, want: %+v", qa1_test, qa1)
    }
}

var create_qas []qa.QA = []qa.QA {
    qa.QA {"", "Where are we?", "jckuri", "", ""},
    qa.QA {"", "What are we doing?", "ccedano", "", ""},
    qa.QA {"", "Where's Waldo?", "tpeycere", "", ""},
    qa.QA {"", "Who are we?", "tpeycere", "", ""},
}

func TestCreateQuestions(t *testing.T) {
    for _, qa0 := range create_qas {
        CreateQuestionTest(t, qa0)
    }
    qas2, err := qa.ReadAllQuestions()
    if err != nil {
        t.Error(err)    
    }
    if len(create_qas) != len(qas2) {
        t.Errorf("Some questions were not created.")
    }
}

func UpdateQuestionTest(t *testing.T, qa0 qa.QA) {
    err0 := qa.UpdateQuestion(qa0)
    if err0 != nil {
        t.Error(err0)
    }
    qa1, err1 := qa.ReadQuestion(qa0.Id)
    if err1 != nil {
        t.Error(err1)
    }
    if qa0 != qa1 {
        t.Errorf("Got: %+v, want: %+v", qa1, qa0)
    }
}

var update_qas []qa.QA = []qa.QA {
    qa.QA {"1", "Where are we?", "jckuri", "We are in Latin America.", "ccedano"},
    qa.QA {"2", "What are we doing?", "ccedano", "We are programming a project.", "jckuri"},
    qa.QA {"3", "Where's Waldo?", "tpeycere", "Here.", "jckuri"},
}

func TestUpdateQuestions(t *testing.T) {
    for _, qa0 := range update_qas {
        UpdateQuestionTest(t, qa0)
    }
}

func TestUpdateInexistentQuestion(t *testing.T) {
    err5 := qa.UpdateQuestion(qa.QA {"5", "Does question 5 exist?", "jckuri", "No, it doesn't.", "ccedano"},)
    if err5 == nil {
        t.Error("Question 5 doesn't exist. So, updating question 5 should have caused an error.")
    }
}

func TestReadQuestionsOfUser(t *testing.T) {
    questions_got, err1 := qa.ReadQuestionsOfUser("ccedano")
    if err1 != nil {
        t.Error(err1)
    }
    questions_want := []qa.QA {update_qas[1]}
    if !reflect.DeepEqual(questions_got, questions_want) {
        t.Errorf("Got: %+v, want: %+v", questions_got, questions_want)
    }
}

func TestReadAnswersOfUser(t *testing.T) {
    questions_got, err1 := qa.ReadAnswersOfUser("jckuri")
    if err1 != nil {
        t.Error(err1)
    }
    questions_want := []qa.QA {update_qas[1], update_qas[2]}
    if !reflect.DeepEqual(questions_got, questions_want) {
        t.Errorf("Got: %+v, want: %+v", questions_got, questions_want)
    }
}

func TestDeleteQuestion(t *testing.T) {
    err1 := qa.DeleteQuestion("4")
    if err1 != nil {
        t.Error(err1)
    }
    qas2, err2 := qa.ReadAllQuestions()
    if err2 != nil {
        t.Error(err2)    
    }
    if !reflect.DeepEqual(qas2, update_qas) {
        t.Errorf("Got: %+v, want: %+v", qas2, update_qas)
    }
}

func TestDeleteInexistentQuestion(t *testing.T) {
    err5 := qa.DeleteQuestion("5")
    if err5 == nil {
        t.Error("Question 5 doesn't exist. So, deleting question 5 should have caused an error.")
    }
}
