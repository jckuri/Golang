package main

import qa_gokit "qa/pkg/gokit"

func main() {
    qa_gokit.StartServer()
}
