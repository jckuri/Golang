curl 127.0.0.1:8080/read_all_questions
