go run cmd/gokit_server/main.go
