package main

import "qa/pkg"

func main() {
    qa.StartServer()
}
