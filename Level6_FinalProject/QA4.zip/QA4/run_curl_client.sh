curl -XPOST -d '{"id":"1"}' http://localhost:8080/questions2
echo ""
curl http://localhost:8080/questions
