package qa

import (
    "fmt"
    "encoding/json"
    "io/ioutil"
    "log"
    "net/http"
    "github.com/gorilla/mux"
    "strconv"
    //"context"
    //"errors"
    //"go.mongodb.org/mongo-driver/bson"
    //"go.mongodb.org/mongo-driver/bson/primitive"
    //"go.mongodb.org/mongo-driver/mongo"
    //"go.mongodb.org/mongo-driver/mongo/options"
    
    //"qa/pkg"
)

func QAsToString(qas []*QA) string {
    s := ""
    for _, qa := range qas {
        s += fmt.Sprintf("%+v ", qa)
    }
    return s
}

func ReadQuestion(w http.ResponseWriter, r *http.Request) {
    questionId := mux.Vars(r)["id"]
    qa, err := GetQA(questionId)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: Question ID does not exist.")
    } else {
        w.WriteHeader(http.StatusOK)
        fmt.Fprintf(w, "%+v", qa)
    }
}

func ReadAllQuestions(w http.ResponseWriter, r *http.Request) {
    qas, err := GetAll()
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: Questions could not be read.")
    } else {
        w.WriteHeader(http.StatusOK)
        fmt.Fprintf(w, "%+v", QAsToString(qas))
    }
}

func ReadQuestionsOfUser(w http.ResponseWriter, r *http.Request) {
    quser := mux.Vars(r)["user"]
    qas, err := GetQuestionsOfUser(quser)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: No questions of user found.")
    } else {
        w.WriteHeader(http.StatusOK)
        fmt.Fprintf(w, "%+v", QAsToString(qas))
    }
}

func ReadAnswersOfUser(w http.ResponseWriter, r *http.Request) {
    auser := mux.Vars(r)["user"]
    qas, err := GetQuestionsOfUser(auser)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: No answers of user found.")
    } else {
        w.WriteHeader(http.StatusOK)
        fmt.Fprintf(w, "%+v", QAsToString(qas))
    }
}

func CreateQuestion(w http.ResponseWriter, r *http.Request) {
    reqBody, err := ioutil.ReadAll(r.Body)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: Body of request must contain a question description.")
        return
    }
    var question QA
    json.Unmarshal(reqBody, &question)
    QuestionId ++
    qa1 := QA {Id: strconv.Itoa(QuestionId), Question: question.Question, QUser: question.QUser, Answer: "", AUser: ""}
    err = CreateQA(&qa1)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: Question could not be created.")
    } else {
        w.WriteHeader(http.StatusCreated)
        fmt.Fprintf(w, "%+v", qa1)    
    }
}

func UpdateQuestion(w http.ResponseWriter, r *http.Request) {
    reqBody, err := ioutil.ReadAll(r.Body)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: Body of request must contain a question description.")
        return
    }
    var question QA
    json.Unmarshal(reqBody, &question)
    questionId := mux.Vars(r)["id"]
    _, err = GetQA(questionId)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: Question ID does not exist.")
    } else {
        qa1 := QA {Id: questionId, Question: question.Question, QUser: question.QUser, Answer: question.Answer, AUser: question.AUser}
        err = UpdateQA(&qa1)
        if err != nil {
            w.WriteHeader(http.StatusBadRequest)
            fmt.Fprintf(w, "ERROR: Question could not be updated.")
        } else {
            w.WriteHeader(http.StatusOK)
            fmt.Fprintf(w, "%+v", qa1)    
        }
    }
}

func DeleteQuestion(w http.ResponseWriter, r *http.Request) {
    questionId := mux.Vars(r)["id"]
    qa1, err := GetQA(questionId)
    if err != nil {
        w.WriteHeader(http.StatusBadRequest)
        fmt.Fprintf(w, "ERROR: Question ID does not exist.")
    } else {
        err = DeleteQA(questionId)
        if err != nil {
            w.WriteHeader(http.StatusBadRequest)
            fmt.Fprintf(w, "ERROR: Question could not be deleted.")
        } else {
            w.WriteHeader(http.StatusOK)
            fmt.Fprintf(w, "%+v", qa1)
        }
    }
}

func StartServer() {
    //MongoExperiment()
    router := mux.NewRouter().StrictSlash(true)
    router.HandleFunc("/ReadQuestion/{id}", ReadQuestion).Methods("GET")
    router.HandleFunc("/ReadAllQuestions", ReadAllQuestions).Methods("GET")
    router.HandleFunc("/ReadQuestionsOfUser/{user}", ReadQuestionsOfUser).Methods("GET")
    router.HandleFunc("/ReadAnswersOfUser/{user}", ReadAnswersOfUser).Methods("GET")
    router.HandleFunc("/CreateQuestion", CreateQuestion).Methods("POST")
    router.HandleFunc("/UpdateQuestion/{id}", UpdateQuestion).Methods("PUT")
    router.HandleFunc("/DeleteQuestion/{id}", DeleteQuestion).Methods("DELETE")
    fmt.Println("Listening requests...")
    log.Fatal(http.ListenAndServe(":8080", router))
}
