package qa

import (
	"context"
	"errors"
	"fmt"
	"github.com/go-kit/kit/endpoint"
	"qa/pkg"
)

// Endpoints are exposed
type Endpoints struct {
    GetQAEndpoint endpoint.Endpoint
    GetAllQAEndpoint endpoint.Endpoint
    GetQA2Endpoint endpoint.Endpoint
    GetAllQA2Endpoint endpoint.Endpoint
}

// MakeGetEndpoint returns the response from our service "get"
func MakeGetQAEndpoint(srv Service) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		req := request.(GetQARequest)
		fmt.Printf("req=%v\n", req)
		question, quser, answer, auser, err := srv.GetQA(ctx, req.Id)
		if err != nil {
			return GetQAResponse{question, quser, answer, auser, err.Error()}, nil
		}
		return GetQAResponse{question, quser, answer, auser, ""}, nil
	}
}

// Get endpoint mapping
func (e Endpoints) GetQA(ctx context.Context, id string) (string, string, string, string, error) {
	req := GetQARequest{}
	resp, err := e.GetQAEndpoint(ctx, req)
	if err != nil {
		return "", "", "", "", err
	}
	getResp := resp.(GetQAResponse)
	if getResp.Err != "" {
		return "", "", "", "", errors.New(getResp.Err)
	}
	return getResp.Question, getResp.QUser, getResp.Answer, getResp.AUser, nil
}

func MakeGetAllQAEndpoint(srv Service) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		req := request.(GetAllQARequest)
		fmt.Printf("MakeGetAllEndpoint: req=%v\n", req)
		qas, err := srv.GetAllQA(ctx)
		if err != nil {
			return GetAllQAResponse{nil, err.Error()}, nil
		}
		return GetAllQAResponse{qas, ""}, nil
	}
}

func (e Endpoints) GetAllQA(ctx context.Context) ([]qa.QA, error) {
	req := GetAllQARequest{}
	fmt.Printf("GetAll: req=%v\n", req)
	resp, err := e.GetAllQAEndpoint(ctx, req)
	if err != nil {
		return nil, err
	}
	getAllResp := resp.(GetAllQAResponse)
	if getAllResp.Err != "" {
		return nil, errors.New(getAllResp.Err)
	}
	return getAllResp.QAs, nil
}

// MakeGetEndpoint returns the response from our service "get"
func MakeGetQA2Endpoint(srv Service) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		req := request.(GetQA2Request)
		fmt.Printf("req=%v\n", req)
		qa1, err := srv.GetQA2(ctx, req.Id)
		if err != nil {
			return GetQA2Response{qa.QA {}, err.Error()}, nil
		}
		return GetQA2Response{qa1, ""}, nil
	}
}

// Get endpoint mapping
func (e Endpoints) GetQA2(ctx context.Context, id string) (qa.QA, error) {
	req := GetQA2Request{}
	resp, err := e.GetQA2Endpoint(ctx, req)
	if err != nil {
		return qa.QA {}, err
	}
	getResp := resp.(GetQA2Response)
	if getResp.Err != "" {
		return qa.QA {}, errors.New(getResp.Err)
	}
	return getResp.QA, nil
}

func MakeGetAllQA2Endpoint(srv Service) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		req := request.(GetAllQA2Request)
		fmt.Printf("MakeGetAllEndpoint: req=%v\n", req)
		qas, err := srv.GetAllQA2(ctx, req.Id)
		if err != nil {
			return GetAllQA2Response{nil, err.Error()}, nil
		}
		return GetAllQA2Response{qas, ""}, nil
	}
}

func (e Endpoints) GetAllQA2(ctx context.Context, id string) ([]qa.QA, error) {
	req := GetAllQA2Request{}
	fmt.Printf("GetAll: req=%v, id=%v\n", req, id)
	resp, err := e.GetAllQA2Endpoint(ctx, req)
	if err != nil {
		return nil, err
	}
	getAllResp := resp.(GetAllQA2Response)
	if getAllResp.Err != "" {
		return nil, errors.New(getAllResp.Err)
	}
	return getAllResp.QAs, nil
}

