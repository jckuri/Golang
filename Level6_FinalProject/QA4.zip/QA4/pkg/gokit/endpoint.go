package qa

import (
	"context"
	"errors"
	"fmt"
	"github.com/go-kit/kit/endpoint"
)

// Endpoints are exposed
type Endpoints struct {
	GetEndpoint      endpoint.Endpoint
}

// MakeGetEndpoint returns the response from our service "get"
func MakeGetEndpoint(srv Service) endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		req := request.(getRequest) // we really just need the request, we don't use any value from it
		fmt.Printf("req=%v\n", req)
		question, quser, answer, auser, err := srv.Get(ctx, req.Id)
		if err != nil {
			return getResponse{question, quser, answer, auser, err.Error()}, nil
		}
		return getResponse{question, quser, answer, auser, ""}, nil
	}
}

// Get endpoint mapping
func (e Endpoints) Get(ctx context.Context, id string) (string, string, string, string, error) {
	req := getRequest{}
	resp, err := e.GetEndpoint(ctx, req)
	if err != nil {
		return "", "", "", "", err
	}
	getResp := resp.(getResponse)
	if getResp.Err != "" {
		return "", "", "", "", errors.New(getResp.Err)
	}
	return getResp.Question, getResp.QUser, getResp.Answer, getResp.AUser, nil
}

