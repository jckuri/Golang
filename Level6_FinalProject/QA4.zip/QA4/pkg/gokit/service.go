package qa

import (
	"context"
	//"time"
	"fmt"
	"qa/pkg"
)

// Service provides some "date capabilities" to your application
type Service interface {
	Get(ctx context.Context, id string) (string, string, string, string, error)
}

type dateService struct{}

// NewService makes a new Service.
func NewService() Service {
	return dateService{}
}

// Get will return today's date
func (dateService) Get(ctx context.Context, id string) (string, string, string, string, error) {
    fmt.Printf("CALLING: qa.GetQA(%v)\n", id)
    qa1, err := qa.GetQA(id)
    if err != nil {
        return "", "", "", "", err
    } else {
        return qa1.Question, qa1.QUser, qa1.Answer, qa1.AUser, nil
    }
}
