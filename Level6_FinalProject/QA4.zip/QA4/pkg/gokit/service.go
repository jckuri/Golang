package qa

import (
	"context"
	"fmt"
	"qa/pkg"
)

// Service provides some "date capabilities" to your application
type Service interface {
    GetQA(ctx context.Context, id string) (string, string, string, string, error)
    GetAllQA(ctx context.Context) ([]qa.QA, error)
    GetQA2(ctx context.Context, id string) (qa.QA, error)
    GetAllQA2(ctx context.Context, id string) ([]qa.QA, error)
}

type QAService struct{}

// NewService makes a new Service.
func NewService() Service {
	return QAService{}
}

func (QAService) GetQA(ctx context.Context, id string) (string, string, string, string, error) {
    fmt.Printf("CALLING: qa.GetQA(%v)\n", id)
    qa1, err := qa.GetQA(id)
    if err != nil {
        return "", "", "", "", err
    } else {
        return qa1.Question, qa1.QUser, qa1.Answer, qa1.AUser, nil
    }
}

func (QAService) GetAllQA(ctx context.Context) ([]qa.QA, error) {
    fmt.Printf("CALLING: qa.GetAll()\n")
    qas, err := qa.GetAllQA()
    fmt.Printf("RESULT: %+v\n", qas)
    if err != nil {
        return nil, err
    } else {
        return qas, nil
    }
}

func (QAService) GetQA2(ctx context.Context, id string) (qa.QA, error) {
    fmt.Printf("CALLING: qa.GetQA(%v)\n", id)
    qa1, err := qa.GetQA(id)
    fmt.Printf("RESULT: %+v\n", qa1)
    if err != nil {
        return qa.QA {}, err
    } else {
        return qa1, nil
    }
}

func (QAService) GetAllQA2(ctx context.Context, id string) ([]qa.QA, error) {
    fmt.Printf("CALLING: qa.GetAll(), id=%v\n", id)
    qas, err := qa.GetAllQA()
    fmt.Printf("RESULT: %+v\n", qas)
    if err != nil {
        return nil, err
    } else {
        return qas, nil
    }
}
