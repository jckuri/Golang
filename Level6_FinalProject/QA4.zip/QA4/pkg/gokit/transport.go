package qa

import (
	"context"
	"encoding/json"
	"net/http"
	"fmt"
	"qa/pkg"
)

// In the first part of the file we are mapping requests and responses to their JSON payload.
type GetQARequest struct{
    Id string `json:"id"`
}

type GetQAResponse struct {
    Question string `json:"question"`
    QUser string `json:"quser"`
    Answer string `json:"answer"`
    AUser string `json:"auser"`
    Err  string `json:"err,omitempty"`
}

// In the second part we will write "decoders" for our incoming requests
func DecodeGetQARequest(ctx context.Context, r *http.Request) (interface{}, error) {
    	var req GetQARequest
	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		return nil, err
	}
	return req, nil
}

type GetAllQARequest struct{
}

type GetAllQAResponse struct {
    QAs []qa.QA `json:"qas"`
    Err  string `json:"err,omitempty"`
}

// In the second part we will write "decoders" for our incoming requests
func DecodeGetAllQARequest(ctx context.Context, r *http.Request) (interface{}, error) {
    var req GetAllQARequest
    return req, nil
/*
    	var req GetAllQARequest
	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		return nil, err
	}
	return req, nil
*/
}

// In the first part of the file we are mapping requests and responses to their JSON payload.
type GetQA2Request struct{
    Id string `json:"id"`
}

type GetQA2Response struct {
    QA qa.QA `json:"qa"`
    Err  string `json:"err,omitempty"`
}

// In the second part we will write "decoders" for our incoming requests
func DecodeGetQA2Request(ctx context.Context, r *http.Request) (interface{}, error) {
    	var req GetQA2Request
	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		return nil, err
	}
	return req, nil
}

type GetAllQA2Request struct{
    Id string `json:"id"`
}

type GetAllQA2Response struct {
    QAs []qa.QA `json:"qas"`
    Err  string `json:"err,omitempty"`
}

// In the second part we will write "decoders" for our incoming requests
func DecodeGetAllQA2Request(ctx context.Context, r *http.Request) (interface{}, error) {
    	var req GetAllQA2Request
	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		return nil, err
	}
	return req, nil
}

// Last but not least, we have the encoder for the response output
func EncodeResponse(ctx context.Context, w http.ResponseWriter, response interface{}) error {
    fmt.Printf("encodeResponse: %v\n", response)
    return json.NewEncoder(w).Encode(response)
}
