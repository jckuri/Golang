package qa

import (
	"net/http"
	httptransport "github.com/go-kit/kit/transport/http"
	"github.com/gorilla/handlers"
	"github.com/gorilla/mux"
	"fmt"
	"os"
)

func NewServer(svc Service, port string) *http.Server {
	endpoints := Endpoints{
		GetQAEndpoint: MakeGetQAEndpoint(svc),
		GetAllQAEndpoint: MakeGetAllQAEndpoint(svc),
		GetQA2Endpoint: MakeGetQA2Endpoint(svc),
		GetAllQA2Endpoint: MakeGetAllQA2Endpoint(svc),
	}
	r := makeHandlers(endpoints)
	server := &http.Server{
		Addr: port,
		Handler: handlers.CORS(
			handlers.AllowedHeaders([]string{"Content-Type"}),
			handlers.AllowedMethods([]string{"GET", "POST", "PUT", "DELETE"}),
		)(r),
	}
	return server
}

func makeHandlers(endpoints Endpoints) *mux.Router {
	r := mux.NewRouter()
	r.Use(commonMiddleware)
	r.Methods("POST").Path("/question").Handler(httptransport.NewServer(endpoints.GetQAEndpoint, DecodeGetQARequest, EncodeResponse))
	r.Methods("GET").Path("/questions").Handler(httptransport.NewServer(endpoints.GetAllQAEndpoint, DecodeGetAllQARequest, EncodeResponse))
	r.Methods("POST").Path("/question2").Handler(httptransport.NewServer(endpoints.GetQA2Endpoint, DecodeGetQA2Request, EncodeResponse))
	r.Methods("POST").Path("/questions2").Handler(httptransport.NewServer(endpoints.GetAllQA2Endpoint, DecodeGetAllQA2Request, EncodeResponse))
	return r
}

func commonMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        w.Header().Add("Content-Type", "application/json")
        next.ServeHTTP(w, r)
    })
}

func StartServer() {
	svc := NewService()
	if svc == nil {
		fmt.Println("Failed to create service")
		os.Exit(2)
	}
	errc := make(chan error)
	server := NewServer(svc, ":8080")

	go func() {
		fmt.Printf("HTTP service started listening %v\n", server.Addr)
		errc <- server.ListenAndServe()
	}()
	fmt.Printf("exit %v\n", <-errc)
}
