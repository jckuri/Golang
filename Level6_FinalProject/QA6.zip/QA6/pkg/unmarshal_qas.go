package qa

import (
    "encoding/json"
    "fmt"
)

type UnmarshalledQA map[string]QA

func ParseQuestionFromJson(json1 string) QA {
    bytes := []byte(json1)
    var uqa UnmarshalledQA
    json.Unmarshal(bytes, &uqa)
    return uqa["qa"]
}

type SliceQA []QA
type UnmarshalledQAs map[string]SliceQA

func ParseQuestionsFromJson(json1 string) SliceQA {
    bytes := []byte(json1)
    var uqas UnmarshalledQAs
    json.Unmarshal(bytes, &uqas)
    return uqas["qas"]
}

func UnmarshalErr(json1 string) error {
    bytes := []byte(json1)
    var error_map map[string]string
    json.Unmarshal(bytes, &error_map)
    if err, ok := error_map["err"]; ok {
        return fmt.Errorf("REMOTE ERROR: %", err)
    } 
    return nil
}
