package qa

import (
    "fmt"
    "net/http"
    //"qa/pkg"
)

var baseUrl = "http://127.0.0.1:8080"

func GetUrl(path string) string {
    return fmt.Sprintf("%v%v", baseUrl, path)
}

func MicroServiceError(status int) error {
    return fmt.Errorf("MICROSERVICE ERROR: %v %v", status, http.StatusText(status))
}

func ReadQuestion(id string) (QA, error) {
    path := fmt.Sprintf("/read_question/%v", id)
    response, status := JsonRequest(GetUrl(path), http.MethodGet, "")
    if status != 200 {
        return QA {}, MicroServiceError(status)
    }
    uerr := UnmarshalErr(response)
    if uerr != nil {
        return QA {}, uerr
    }
    qa1 := ParseQuestionFromJson(response)
    return qa1, nil
}

func ReadAllQuestions() ([]QA, error) {
    response, status := JsonRequest(GetUrl("/read_all_questions"), http.MethodGet, "")
    if status != 200 {
        return nil, MicroServiceError(status)
    }
    uerr := UnmarshalErr(response)
    if uerr != nil {
        return nil, uerr
    }
    qas := ParseQuestionsFromJson(response)
    return qas, nil
}

func CreateQuestion(qa1 QA) (QA, error) {
    values := make(map[string]interface{})
    values["qa"] = qa1
    response, status := JsonMapRequest(GetUrl("/create_question"), http.MethodPost, values)
    if status != 200 {
        return QA {}, MicroServiceError(status)
    }
    uerr := UnmarshalErr(response)
    if uerr != nil {
        return QA {}, uerr
    }
    qa2 := ParseQuestionFromJson(response)
    return qa2, nil
}

func UpdateQuestion(qa1 QA) error {
    values := make(map[string]interface{})
    values["qa"] = qa1
    response, status := JsonMapRequest(GetUrl("/update_question"), http.MethodPut, values)
    if status != 200 {
        return MicroServiceError(status)
    }
    return UnmarshalErr(response)
}

func DeleteQuestion(id string) error {
    path := fmt.Sprintf("/delete_question/%v", id)
    response, status := JsonRequest(GetUrl(path), http.MethodDelete, "")
    //fmt.Println("DELETE RESPONSE:", response)
    if status != 200 {
        return MicroServiceError(status)
    }
    return UnmarshalErr(response)
}

func DeleteAllQuestions() error {
    response, status := JsonRequest(GetUrl("/delete_all_questions"), http.MethodDelete, "")
    if status != 200 {
        return MicroServiceError(status)
    }
    return UnmarshalErr(response)
}

func ReadQuestionsOfUser(user string) ([]QA, error) {
    path := fmt.Sprintf("/read_questions_of_user/%v", user)
    response, status := JsonRequest(GetUrl(path), http.MethodGet, "")
    if status != 200 {
        return nil, MicroServiceError(status)
    }
    uerr := UnmarshalErr(response)
    if uerr != nil {
        return nil, uerr
    }
    qas := ParseQuestionsFromJson(response)
    return qas, nil
}

func ReadAnswersOfUser(user string) ([]QA, error) {
    path := fmt.Sprintf("/read_answers_of_user/%v", user)
    response, status := JsonRequest(GetUrl(path), http.MethodGet, "")
    if status != 200 {
        return nil, MicroServiceError(status)
    }
    uerr := UnmarshalErr(response)
    if uerr != nil {
        return nil, uerr
    }
    qas := ParseQuestionsFromJson(response)
    return qas, nil
}
