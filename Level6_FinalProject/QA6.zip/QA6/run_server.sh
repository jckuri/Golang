go run cmd/server/main.go
